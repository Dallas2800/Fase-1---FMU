package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener{

    // Login e Registro
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle drawerToggle;

    // QUIZ TIME
    TextView perguntasTotalTextView;
    TextView perguntasTextView;
    Button respA, respB, respC, respD;
    Button submitBtn;
    int score = 0;
    int totalperguntas = PerguntaReposta.question.length;
    int currentQuestionIndex = 0;
    String selecioneResp = "";

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(drawerToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressLint("MissingInflatedId") // solução temporaria para erro das linhas 47 e 48
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // QUIZ TIME
        perguntasTotalTextView = findViewById(R.id.total_perguntas); // dando erro pq não esta no main activity
        perguntasTextView = findViewById(R.id.pergunta); // dando erro pq não esta no main activity
        respA = findViewById(R.id.resp_A);
        respB = findViewById(R.id.resp_B);
        respC = findViewById(R.id.resp_C);
        respD = findViewById(R.id.resp_D);
        submitBtn = findViewById(R.id.submit);

        respA.setOnClickListener(this);
        respB.setOnClickListener(this);
        respC.setOnClickListener(this);
        respD.setOnClickListener(this);
        submitBtn.setOnClickListener(this);

        perguntasTotalTextView.setText("Total de perguntas" + totalperguntas);

        loadNewQuestion();

        //Login&Registro

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home: {
                        Toast.makeText(MainActivity.this, "Inicio Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.contact: {
                        Toast.makeText(MainActivity.this, "Contato Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.gallery: {
                        Toast.makeText(MainActivity.this, "Imagens Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.about: {
                        Toast.makeText(MainActivity.this, "Sobre Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.Login: {
                        Toast.makeText(MainActivity.this, "Login Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.share: {
                        Toast.makeText(MainActivity.this, "Compartilhe Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.rate_us: {
                        Toast.makeText(MainActivity.this, "Nota Selecionado", Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
                return false;
            }
        });



        }

    @Override
    public void onBackPressed() {

        respA.setBackgroundColor(Color.WHITE);
        respB.setBackgroundColor(Color.WHITE);
        respC.setBackgroundColor(Color.WHITE);
        respD.setBackgroundColor(Color.WHITE);

        if(drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else{
            super.onBackPressed();
        }
    }

    @Override
    public void onClick(View view) {
        Button clickedButton = (Button) view;
        if(clickedButton.getId() == R.id.submit){
            if(selecioneResp.equals(PerguntaReposta.respCorreta[currentQuestionIndex])){
                score++;
            }
            currentQuestionIndex++;
            loadNewQuestion();

        }else {
            // escolhe o botão clicado
            selecioneResp = clickedButton.getText().toString();
            clickedButton.setBackgroundColor(Color.YELLOW);
        }
    }

    void loadNewQuestion() {

        if(currentQuestionIndex == totalperguntas) {
            endQuiz();
            return;
        }

        perguntasTextView.setText(PerguntaReposta.question[currentQuestionIndex]);
        respA.setText(PerguntaReposta.escolhas[currentQuestionIndex][0]);
        respB.setText(PerguntaReposta.escolhas[currentQuestionIndex][0]);
        respC.setText(PerguntaReposta.escolhas[currentQuestionIndex][0]);
        respD.setText(PerguntaReposta.escolhas[currentQuestionIndex][0]);
    }

    void endQuiz() {
        String passStatus = "";
        if(score > totalperguntas*060){
            passStatus = "Passou";
        }else {
            passStatus = "Falhou";
        }

        new AlertDialog.Builder(this)
                .setTitle(passStatus)
                .setMessage("Score is "+ score +" out of "+ totalperguntas)
                .setPositiveButton("Restart", (dialogInterface, i) -> restartQuiz() )
                .setCancelable(false)
                .show();
    }

    void restartQuiz() {
        score = 0;
        currentQuestionIndex = 0;
        loadNewQuestion();
    }


}
