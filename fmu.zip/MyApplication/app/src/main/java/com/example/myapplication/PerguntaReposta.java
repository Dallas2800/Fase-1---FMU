package com.example.myapplication;

public class PerguntaReposta {

    public static String question[] ={
            "Qual a cor do chapeu do chaves?",
            "Quantos filhotes uma gata pode dar a luz de uma so vez?",
            "Porque o céu é azul?"

    };

    public static String escolhas[][] = {
            {"amaryellow","Azul nenem","verde","VERDE MACHO"},
            {"1-2","8-1", "nouve - cinco", "2-4"},
            {"porque sim", "Porque não existe flor preta ?",
            "Deus quis", "reflexo do oceano"}
    };

    public static String respCorreta[] = {
            "verde",
            "2-4",
            "reflexo do oceano"
    };
}
